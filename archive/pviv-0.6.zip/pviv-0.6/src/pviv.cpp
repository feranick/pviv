//*****************************************************************************
//                                                         
//		PV-IV						 
//														 
//		v. 0.5 (grace)
//
//		2011 - Nicola Ferralis 					 
//                                                        
//		PV-IV photovoltaic data anlaysys
//
//		This program (source code and binaries) is free software; 
//		you can redistribute it and/or modify it under the terms of the
//		GNU General Public License as published by the Free Software 
//		Foundation, in version 3 of the License.
//
//		This program is distributed in the hope that it will be useful,
//		but WITHOUT ANY WARRANTY; without even the implied warranty of
//		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//		GNU General Public License for more details.
//
//		You can find a complete copy of the GNU General Public License at:
//		http://www.gnu.org/licenses/gpl.txt
//												             
//**********************************************************************************
/* To do

1. Fix discrepancy in npoints between a.dat and c.csv
3. fix boundaries for Voc and Isc.
4. Windows version
5. Preferences.
6 General cleanup.
*/


//////////////
#if     _MSC_VER
// Use these for MSVC
#include <fstream>
#include <iostream>
#include <string>
#include <math.h>
#include <stdio.h>
#include <errno.h>
#include <windows.h>

#define snprintf sprintf_s

using namespace std; 

#define popen _popen 
#define pclose     _pclose   
#define MSini 1   // 1: save config file in C:/ (MS32 only)    0: save it in the same folder 
#include "direct.h"			

#else
// Use these for gcc
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string.h>
#include <math.h>
#include <stdio.h>  
#include <errno.h>
#include <grace_np.h>
#include <time.h>
#define MSini 0
using namespace std; 
#endif

#define GPFIFO "./gpio" 

#define PATH_MAX 200
#define CMAXI 200

int const Max=1000000;
int operate(char *namein, int s);
int parser(char *namein);
double V[Max], I[Max], P[Max];

int i,j,npoints,vplot,steps,type, numatoms, Ytypef, ctsconv, xaxis, flag,bconv;
int pl=0;

char formula[20];
char version[]="0.5 20110414";
char summary[CMAXI];

typedef struct coord{
	double x;
	double y;
	} coord;

typedef struct mcoord{
	float x[Max];
	float y[Max];
	} mcoord;

double length=37; // in mm length cell.
double width=33; // in mm width cell.
double Pin=100; //Power density 100mW/cm^2

int flags=0;
int flagr=0;
int filetype=0;

coord Maximum();
coord linear(double x1, double x2, double y1, double y2, double x0);

void IniPlot(char* name);
void Plot(char* name);
void PlotSettings();
void ClosePlot();

int ReadKey();
float ReadKeyF();

void my_error_function(const char *msg);


int main(int argc, char *argv[])

{ 	if(argc<2)
		{
		time_t rawtime;
 		struct tm * timeinfo;
 		time ( &rawtime );
  		timeinfo = localtime ( &rawtime );

		strftime (summary,CMAXI,"Summary_%Y-%m-%d_%H-%M.csv",timeinfo);

		if(flags==0)
			{ofstream out(summary);
			out<<"File,Voc(V),Isc(A),Pmax(W),Vmax(V),Imax(A),FF,Efficiency(%)\n";
			out.close();
			flags=1;}

		filetype=2;
		
		cout<<"\n_________________________________________________\n";
		cout<<"PV-IV  Photovoltaic data analysis\n";
		cout<<"\nPress: \n0) exit\t\t\t2) about\n1) Go\n";
		type=ReadKey();
		}	

	if(argc>=2)
	{	for(int i=1; i<argc; i++)
			{parser(argv[i]);
			//readdata(argv[i]);
			if(flagr==0)
				{operate(argv[i], 0);}	
			}
	return 0; }

	if(type==0)
		{ClosePlot();
		return 0;}	

	if(type==2)
		{cout<<"\n\nComment, suggestions, bugs: Nicola Ferralis <feranick@gmail.com>";
		main(0,0);}

	if(type==1)
		{flagr=0;
		char *namein;
		namein=(char *)malloc(sizeof(char[CMAXI]));
		cout<<"name input file (WITH extension): ";
		cin>>namein;
		parser(namein);
		//readdata(namein);
		if(flagr==0)		
			{operate(namein, 1);}
		free(namein);
		main(0,0);}

		return 0;
	}

//OPERATE 
int parser(char *namein)
	{
	ifstream infile(namein);
	if(!infile)
		{
		cout<<"\n file '"<< namein<<"' not found\n";
		flagr=1;		
		return 0;
		}

	char *temp;
	temp=(char *)malloc(sizeof(char[CMAXI]));


	infile>>temp;
	if(strcmp(temp,"<SYSTEM")==0) 
		{filetype=0;}
	if(strcmp(temp,"Vraw,Iraw,Icorrected,Ifit")==0) 
		{filetype=1;}
	if(strcmp(temp,"Vraw,Iraw,Icorrected,Ifit")!=0 && strcmp(temp,"<SYSTEM")!=0)
		{filetype=2;}
		
		char *outname;
		outname=(char *)malloc(sizeof(char[CMAXI]));

	if(filetype==0 || filetype==1)
		{
		string text;
		char *asciiname;
		asciiname=(char *)malloc(sizeof(char[CMAXI]));

		snprintf(asciiname, CMAXI, "%s.dat", namein);
		snprintf(outname, CMAXI, "power_%s", asciiname);

		
		if(filetype==0)
			{while(getline(infile,text))
				{infile>>text;
				if(text=="Vraw,Iraw,Icorrected,Ifit")
					{break;}				
				}
			}
		
		ofstream out(asciiname);
		ofstream outp(outname);

		getline(infile,text);
		j=0;
		while(getline(infile,text, ','))		
			{//this is to remove the " DATA>" tag at the end of the txt file.
			for(unsigned int i=0;i<text.length();i++) 
				{if(text[i]=='\n') 
					{text.erase(text.end()-2,text.end() );}
				}
			if(text==" DATA>")
				{break;}
						
			//n1=atof( text.c_str() );
			V[j]=atof( text.c_str() );			
			infile>>I[j]>>temp>>temp;
			P[j]=V[j]*I[j];

			out<<V[j]<<"\t"<<I[j]<<"\n";
			outp<<V[j]<<"\t"<<P[j]<<"\n";
			j++;}

		npoints = j;
		out.close();
		outp.close();
		free(asciiname);		
		}
		
	if(filetype==2)
		{j=0;
		V[0]=atof(temp );
		infile>>I[0];
		P[0]=V[0]*I[0];
		j=1;
		while(!infile.eof())
			{infile>>V[j]>>I[j];
			P[j]=V[j]*I[j];
			j++;}
		npoints = j-1;

		snprintf(outname, CMAXI, "power_%s", namein);	
		ofstream outp(outname);
		for (j=0; j<npoints; j++)
			{outp<<V[j]<<"\t"<<I[j]<<"\n";}
		outp.close();
		}
		
		infile.close();
		free(outname);	
		free(temp);
			
	return 0;	
	}


int operate(char *namein, int s)

{	vplot=1;
	ClosePlot();
	static double Voc, Ioc, Vsc, Isc, Pmax, Vmax, Imax, FF, nu;
	static coord Max;
	char *asciiname, *infoname;
	
	asciiname=(char *)malloc(sizeof(char[CMAXI]));
	infoname=(char *)malloc(sizeof(char[CMAXI]));

	if(filetype==0 || filetype==1)
		{snprintf(asciiname, CMAXI, "%s.dat", namein);}
	else
		{snprintf(asciiname, CMAXI, "%s", namein);}

	
	snprintf(infoname, CMAXI, "info_%s", namein);
	
	
	for(j=0; j<npoints; j++)
		{

		if(I[j-1]<0 && I[j]>-1e-5)
			{Voc=linear(I[j],I[j-1],V[j],V[j-1],0).y;
			Ioc=linear(I[j],I[j-1],V[j],V[j-1],0).x;}
		if(V[j-1]>0 && V[j]<0)
			{Isc=linear(V[j],V[j-1],I[j],I[j-1],0).y;
			Vsc=linear(V[j],V[j-1],I[j],I[j-1],0).x;}
		}

	//here things need to be fixed in cases when the boundaries are not reached.

	//IniPlot(asciiname);
	

	Max=Maximum();	
	Vmax=Max.x;
	Pmax=Max.y;
	Imax=Pmax/Vmax;
	FF=Pmax*(Voc*Isc);	
	nu=(Pmax/((Pin*width*length/100)/1000))*100; //in W

	cout<<"\nFile: "<<namein<<"\n";	
	cout<<"Voc = "<<Voc<<" V\n";
	cout<<"Isc = "<<Isc<<" A\n";
	cout<<"Pmax = "<<Pmax<<" W\n";
	cout<<"Vmax = "<<Vmax<<" V\n";
	cout<<"Imax = "<<Imax<<" I\n";
	cout<<"FF = "<<FF<<"\n";
	cout<<"Efficiency = "<<nu<<" %\n";
	
	ofstream outfile(infoname);

	outfile<<"File: "<<namein<<"\n";
	outfile<<"Voc = "<<Voc<<" V\n";
	outfile<<"Isc = "<<Isc<<" A\n";
	outfile<<"Pmax = "<<Pmax<<" W\n";
	outfile<<"Vmax = "<<Vmax<<" V\n";
	outfile<<"Imax = "<<Imax<<" I\n";
	outfile<<"FF = "<<FF<<"\n";
	outfile<<"Efficiency = "<<nu<<" %\n";
	outfile<<"----------------------------\n";
	
	outfile.close();

	if(s==1)
		{ofstream out(summary, ios::app);
		out<<namein<<","<<Voc<<","<<Isc<<","<<Pmax<<","<<Vmax<<","<<Imax<<","<<FF<<","<<nu<<"\n";
		out.close();}
	
	
	//Plot(outname);			
	cout<<"Info file saved in: "<<infoname<<"\n\n";

	free(infoname);	
	free(asciiname);
	return 0;}
//////////////////////////////////////////////////////
// routines
//Max finder


coord Maximum()
	{
	static coord max;
	max.y=0;
	for(i=0; i<npoints;i++)
		{
		if(P[i]>=max.y)
			{max.y= P[i];
			max.x=V[i];}
		}
	return max;
	}

///////////////////////////////
coord linear(double x2, double x1, double y2, double y1, double x0)
	{double m, a;
	static coord zero;
	m=(y2-y1)/(x2-x1);
	a=y1-m*x1;
	zero.x=x0;
	zero.y=m*x0+a;
	return zero;}
	 
	

//Plot routines

void IniPlot(char* name)
{	pl=0;
	if(vplot==1)
	{
	GraceRegisterErrorFunction(my_error_function);
	if (GraceOpen(2048) == -1) {
	        fprintf(stderr, "Can't run Grace: make sure it's installed. \n");
	        exit(-1);
	  	  }
	PlotSettings();
	GracePrintf("title \"%s\"", name);
	GracePrintf("read \"%s\"", name);
	}
	else
	{}
}


void Plot(char* nameout)
{
	if(vplot==1)	
		{GracePrintf("read \"%s\"", nameout);
		GracePrintf("redraw");}
	else
		{}
	}

void PlotSettings()
	{
	
	GracePrintf("xaxis label \"Voltage [V]\"");
	GracePrintf("yaxis label \"Current [A]\"");
	//GracePrintf("yaxis alt label \"Power [W]\"");
	}	

void ClosePlot()
	{
	if(vplot==1)	
		{GraceClose();}
	else
		{}
}

//************************************
// Keyboard input I/O

int ReadKey()
{	char tkc[10];
	int tk;
	cin>>tkc;
		
	tk=(int) atof(tkc);
	if(tk<0)
		{return 10;}
	else
		{}

	return tk;
}

float ReadKeyF()
{	char tkc[10];
	float tk=0.0;
	cin>>tkc;
	if (strcmp(tkc,"m")==0 || strcmp(tkc,"m2")==0)
		{if (strcmp(tkc,"m")==0)
			{tk=(float) Maximum().y;}
		if (strcmp(tkc,"m2")==0)
			{tk=(float) Maximum().y/2;}
		}

	else
		{	
		tk= (float) atof(tkc);
		if(tk<0)
			{return 10;}
		else
			{}
	}

	return tk;
}

void my_error_function(const char *msg)
{
    fprintf(stderr, "library message: \"%s\"\n", msg);
}

