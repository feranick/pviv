//*****************************************************************************
//                                                         
//		PV-IV						 
//														 
//		v. 0.0.4 (grace)
//
//		2011 - Nicola Ferralis 					 
//                                                        
//		PV-IV photovoltaic data anlaysys
//
//		This program (source code and binaries) is free software; 
//		you can redistribute it and/or modify it under the terms of the
//		GNU General Public License as published by the Free Software 
//		Foundation, in version 3 of the License.
//
//		This program is distributed in the hope that it will be useful,
//		but WITHOUT ANY WARRANTY; without even the implied warranty of
//		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//		GNU General Public License for more details.
//
//		You can find a complete copy of the GNU General Public License at:
//		http://www.gnu.org/licenses/gpl.txt
//												             
//**********************************************************************************

//////////////
#if     _MSC_VER
// Use these for MSVC
#include <fstream>
#include <iostream>
#include <string>
#include <math.h>
#include <stdio.h>
#include <errno.h>
#include <windows.h>

#define snprintf sprintf_s

using namespace std; 

#define popen _popen 
#define pclose     _pclose   
#define MSini 1   // 1: save config file in C:/ (MS32 only)    0: save it in the same folder 
#include "direct.h"			

#else
// Use these for gcc
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <string.h>
#include <math.h>
#include <stdio.h>  
#include <errno.h>
#include <grace_np.h>
#include <time.h>
#define MSini 0
using namespace std; 
#endif

#define GPFIFO "./gpio" 

#define PATH_MAX 200
#define CMAXI 200

int const Max=1000000;
int readdata(char *namein);
int operate(char *namein, int s);
double V[Max], I[Max], P[Max];

int i,j,npoints,vplot,steps,type, numatoms, Ytypef, ctsconv, xaxis, flag,bconv;
int pl=0;

char formula[20];
char version[]="0.0.4 20110412";
char summary[CMAXI];

typedef struct coord{
	double x;
	double y;
	} coord;

typedef struct mcoord{
	float x[Max];
	float y[Max];
	} mcoord;

double length=37; // in mm length cell.
double width=33; // in mm width cell.
double Pin=100; //Power density 100mW/cm^2

int flags=0;
int flagr=0;

coord Maximum();
coord linear(double x1, double x2, double y1, double y2, double x0);

void IniPlot(char* name);
void Plot(char* name);
void PlotSettings();
void ClosePlot();

int ReadKey();
float ReadKeyF();

void my_error_function(const char *msg);


int main(int argc, char *argv[])

{ 	if(argc<2)
		{
		time_t rawtime;
 		struct tm * timeinfo;
 		time ( &rawtime );
  		timeinfo = localtime ( &rawtime );

		strftime (summary,CMAXI,"Summary_%Y-%m-%d_%H-%M.csv",timeinfo);

		if(flags==0)
			{ofstream out(summary);
			out<<"File,Voc(V),Isc(A),Pmax(W),Vmax(V),Imax(A),FF,Efficiency(%)\n";
			out.close();
			flags=1;}
		
		cout<<"\n_________________________________________________\n";
		cout<<"PV-IV  Photovoltaic data analysis\n";
		cout<<"\nPress: \n0) exit\t\t\t2) about\n1) Go\n";
		type=ReadKey();
		}	

	if(argc>=2)
	{	for(int i=1; i<argc; i++)
			{readdata(argv[i]);
			if(flagr==0)
				{operate(argv[i], 0);}
			}	
	return 0; }

	if(type==0)
		{ClosePlot();
		return 0;}	

	if(type==2)
		{cout<<"\n\nComment, suggestions, bugs: Nicola Ferralis <feranick@gmail.com>";
		main(0,0);}

	if(type==1)
		{flagr=0;
		char *namein;
		namein=(char *)malloc(sizeof(char[CMAXI]));
		cout<<"name input file (WITH extension): ";
		cin>>namein;
		readdata(namein);
		if(flagr==0)		
			{operate(namein, 1);}
		free(namein);
		main(0,0);}

		return 0;
	}

//OPERATE 
int readdata(char *namein)
	{
	ifstream infile(namein);
	
	if(!infile)
	{
		cout<<"\n file '"<< namein<<"' not found\n";
		flagr=1;		
		return 0;
	}

	j=0;

	while(!infile.eof())
		{infile>>V[j]>>I[j];
		P[j]=V[j]*I[j];
		j++;}

	infile.close();
	npoints = j-1;
	return 0;	
	}



int operate(char *namein, int s)

{	vplot=1;
	ClosePlot();
	static double Voc, Ioc, Vsc, Isc, Pmax, Vmax, Imax, FF, nu;
	static coord Max;
	char *outname, *infoname;
	//a2=(char *)malloc(sizeof(char[CMAXI]));
	outname=(char *)malloc(sizeof(char[CMAXI]));
	infoname=(char *)malloc(sizeof(char[CMAXI]));

	//snprintf(a2, CMAXI, "%s%s", namein, ".dat");
	snprintf(outname, CMAXI, "power_%s", namein);
	snprintf(infoname, CMAXI, "info_%s", namein);
	//ifstream infile(namein);
	
	
	ofstream outfile(outname);
	
	for(j=0; j<npoints; j++)
		{
		P[j]=V[j]*I[j];
		if(I[j-1]<0 && I[j]>0)
			{Voc=linear(I[j],I[j-1],V[j],V[j-1],0).y;
			Ioc=linear(I[j],I[j-1],V[j],V[j-1],0).x;}
		if(V[j-1]>0 && V[j]<0)
			{Isc=linear(V[j],V[j-1],I[j],I[j-1],0).y;
			Vsc=linear(V[j],V[j-1],I[j],I[j-1],0).x;}
		}

	//IniPlot(namein);
	

	Max=Maximum();	
	Vmax=Max.x;
	Pmax=Max.y;
	Imax=Pmax/Vmax;
	FF=Pmax*(Voc*Isc);	
	nu=(Pmax/((Pin*width*length/100)/1000))*100; //in W

	cout<<"\nFile: "<<namein<<"\n";	
	cout<<"Voc = "<<Voc<<" V\n";
	cout<<"Isc = "<<Isc<<" A\n";
	cout<<"Pmax = "<<Pmax<<" W\n";
	cout<<"Vmax = "<<Vmax<<" V\n";
	cout<<"Imax = "<<Imax<<" I\n";
	cout<<"FF = "<<FF<<"\n";
	cout<<"Efficiency = "<<nu<<" %\n";
	
	ofstream outfile2(infoname);

	outfile2<<"File: "<<namein<<"\n";
	outfile2<<"Voc = "<<Voc<<" V\n";
	outfile2<<"Isc = "<<Isc<<" A\n";
	outfile2<<"Pmax = "<<Pmax<<" W\n";
	outfile2<<"Vmax = "<<Vmax<<" V\n";
	outfile2<<"Imax = "<<Imax<<" I\n";
	outfile2<<"FF = "<<FF<<"\n";
	outfile2<<"Efficiency = "<<nu<<" %\n";
	outfile2<<"----------------------------\n";
	
	outfile2.close();

	if(s==1)
		{ofstream out(summary, ios::app);
		out<<namein<<","<<Voc<<","<<Isc<<","<<Pmax<<","<<Vmax<<","<<Imax<<","<<FF<<","<<nu<<"\n";
		out.close();}
	
	for(i=0; i<npoints; i++)
		{outfile<<V[i]<<"\t"<<P[i]<<"\n";}

	outfile.close();
	//Plot(outname);			
	cout<<"\nPower curve saved in: "<<outname<<"\n";
	cout<<"Info file saved in: "<<infoname<<"\n\n";
	free(outname);	
	free(infoname);	
	return 0;}
//////////////////////////////////////////////////////
// routines
//Max finder


coord Maximum()
	{
	static coord max;
	max.y=0;
	for(i=0; i<npoints;i++)
		{
		if(P[i]>=max.y)
			{max.y= P[i];
			max.x=V[i];}
		}
	return max;
	}

///////////////////////////////
coord linear(double x2, double x1, double y2, double y1, double x0)
	{double m, a;
	static coord zero;
	m=(y2-y1)/(x2-x1);
	a=y1-m*x1;
	zero.x=x0;
	zero.y=m*x0+a;
	return zero;}
	 
	

//Plot routines

void IniPlot(char* name)
{	pl=0;
	if(vplot==1)
	{
	GraceRegisterErrorFunction(my_error_function);
	if (GraceOpen(2048) == -1) {
	        fprintf(stderr, "Can't run Grace: make sure it's installed. \n");
	        exit(-1);
	  	  }
	PlotSettings();
	GracePrintf("title \"%s\"", name);
	GracePrintf("read \"%s\"", name);
	}
	else
	{}
}


void Plot(char* nameout)
{
	if(vplot==1)	
		{GracePrintf("read \"%s\"", nameout);
		GracePrintf("redraw");}
	else
		{}
	}

void PlotSettings()
	{
	
	GracePrintf("xaxis label \"Voltage [V]\"");
	GracePrintf("yaxis label \"Current [A]\"");
	//GracePrintf("yaxis alt label \"Power [W]\"");
	}	

void ClosePlot()
	{
	if(vplot==1)	
		{GraceClose();}
	else
		{}
}

//************************************
// Keyboard input I/O

int ReadKey()
{	char tkc[10];
	int tk;
	cin>>tkc;
		
	tk=(int) atof(tkc);
	if(tk<0)
		{return 10;}
	else
		{}

	return tk;
}

float ReadKeyF()
{	char tkc[10];
	float tk=0.0;
	cin>>tkc;
	if (strcmp(tkc,"m")==0 || strcmp(tkc,"m2")==0)
		{if (strcmp(tkc,"m")==0)
			{tk=(float) Maximum().y;}
		if (strcmp(tkc,"m2")==0)
			{tk=(float) Maximum().y/2;}
		}

	else
		{	
		tk= (float) atof(tkc);
		if(tk<0)
			{return 10;}
		else
			{}
	}

	return tk;
}

void my_error_function(const char *msg)
{
    fprintf(stderr, "library message: \"%s\"\n", msg);
}

